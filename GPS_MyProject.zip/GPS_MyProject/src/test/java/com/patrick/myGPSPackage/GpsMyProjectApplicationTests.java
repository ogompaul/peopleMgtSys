package com.patrick.myGPSPackage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GpsMyProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
